CREATE TABLE dim_time (
    DateID INT PRIMARY KEY AUTO_INCREMENT,
    Date DATE,
    Year INT(4),
    Month INT(2),
    Day INT(2),
    Weekday VARCHAR(10)
);
INSERT INTO dim_time (Date, Year, Month, Day, Weekday)
SELECT DISTINCT
        DATE(STR_TO_DATE(t.InvoiceDate, '%m/%d/%Y %H:%i')) AS Date,  -- Normalisation des dates au format 'YYYY-MM-DD'
        YEAR(STR_TO_DATE(t.InvoiceDate, '%m/%d/%Y %H:%i')) AS Year,   -- Extraction de l'année
        MONTH(STR_TO_DATE(t.InvoiceDate, '%m/%d/%Y %H:%i')) AS Month, -- Extraction du mois
        DAY(STR_TO_DATE(t.InvoiceDate, '%m/%d/%Y %H:%i')) AS Day,     -- Extraction du jour
       DAYNAME(STR_TO_DATE(t.InvoiceDate, '%m/%d/%Y %H:%i')) AS Weekday -- Jour de la semaine
FROM tablef t
WHERE STR_TO_DATE(t.InvoiceDate, '%m/%d/%Y %H:%i') IS NOT NULL;  -- Filtrer les dates invalides

