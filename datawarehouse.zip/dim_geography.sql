CREATE TABLE dim_geography (
    GeographyID INT PRIMARY KEY AUTO_INCREMENT,
    Country VARCHAR(50),
    City VARCHAR(13)
);

INSERT INTO dim_geography (Country, City)
SELECT DISTINCT Country, City
FROM table_2
WHERE Country IS NOT NULL AND City IS NOT NULL;
