CREATE TABLE dim_invoice (
    id INT AUTO_INCREMENT PRIMARY KEY,
    InvoiceID INT,
    InvoiceDate DATETIME,
    TotalAmount DECIMAL(10, 2),
    UNIQUE KEY(InvoiceID, InvoiceDate)  -- Supprimez `TotalAmount` de la clé unique
);
INSERT INTO dim_invoice (InvoiceID, InvoiceDate, TotalAmount)
SELECT DISTINCT f.InvoiceID,
                STR_TO_DATE(t.InvoiceDate, '%m/%d/%Y %H:%i') AS InvoiceDate,
                f.TotalSales AS TotalAmount
FROM factsales2 f
JOIN tablef t ON f.InvoiceID = t.Invoice
WHERE STR_TO_DATE(t.InvoiceDate, '%m/%d/%Y %H:%i') IS NOT NULL
ON DUPLICATE KEY UPDATE 
    TotalAmount = VALUES(TotalAmount);  -- Met à jour le `TotalAmount` en cas de duplication
