CREATE TABLE dim_product (
    StockCode VARCHAR(50) PRIMARY KEY,
    Price DECIMAL(10, 2)
);

INSERT INTO dim_product (StockCode, Price)
SELECT DISTINCT f.StockCode, 
                f.Price
FROM factsales2 f
ON DUPLICATE KEY UPDATE Price = VALUES(Price);

