CREATE TABLE dim_geo(
    GeographyID INT PRIMARY KEY AUTO_INCREMENT,
    Country VARCHAR(50)
);

INSERT INTO dim_geo (Country)
SELECT DISTINCT Country
FROM tablef
WHERE Country IS NOT NULL;
